import React, { useState, useEffect } from 'react';
import { Plus, Moon, Sun, Trash2, Edit2, Check, X } from 'lucide-react';

interface Todo {
  id: string;
  text: string;
  completed: boolean;
}

function App() {
  const [todos, setTodos] = useState<Todo[]>(() => {
    const saved = localStorage.getItem('todos');
    return saved ? JSON.parse(saved) : [];
  });
  const [newTodo, setNewTodo] = useState('');
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode');
    return saved ? JSON.parse(saved) : false;
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [isDeleting, setIsDeleting] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const addTodo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTodo.trim()) return;
    
    const todo: Todo = {
      id: crypto.randomUUID(),
      text: newTodo.trim(),
      completed: false
    };
    
    setTodos(prev => [...prev, todo]);
    setNewTodo('');
  };

  const toggleTodo = (id: string) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: string) => {
    setIsDeleting(id);
    setTimeout(() => {
      setTodos(prev => prev.filter(todo => todo.id !== id));
      setIsDeleting(null);
    }, 400);
  };

  const startEditing = (todo: Todo) => {
    setEditingId(todo.id);
    setEditText(todo.text);
  };

  const saveEdit = () => {
    if (!editText.trim()) return;
    setTodos(prev => prev.map(todo => 
      todo.id === editingId ? { ...todo, text: editText.trim() } : todo
    ));
    setEditingId(null);
  };

  return (
    <div className={`min-h-screen transition-colors duration-500 ${darkMode ? 'dark' : ''}`}>
      <div className="app-background" />
      <div className="container mx-auto px-6 py-16 max-w-2xl relative">
        <div className="flex justify-between items-center mb-10">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-indigo-500 
                         dark:from-indigo-400 dark:to-indigo-300 bg-clip-text text-transparent">
            Task Manager
          </h1>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="theme-toggle"
          >
            {darkMode ? (
              <Sun className="w-6 h-6 text-gray-400" />
            ) : (
              <Moon className="w-6 h-6 text-gray-600" />
            )}
          </button>
        </div>

        <form onSubmit={addTodo} className="mb-10">
          <div className="flex gap-3">
            <input
              type="text"
              value={newTodo}
              onChange={(e) => setNewTodo(e.target.value)}
              placeholder="Add a new task..."
              className="task-input"
            />
            <button type="submit" className="primary-button">
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </form>

        <div className="space-y-4">
          {todos.map(todo => (
            <div
              key={todo.id}
              className={`task-item ${isDeleting === todo.id ? 'deleting' : ''} 
                         ${todo.completed ? 'completed' : ''}`}
            >
              {editingId === todo.id ? (
                <div className="flex gap-3">
                  <input
                    type="text"
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    className="task-input"
                    autoFocus
                  />
                  <button
                    onClick={saveEdit}
                    className="p-2 text-green-600 hover:text-green-700 
                             dark:text-green-500 dark:hover:text-green-400 
                             transition-colors duration-300"
                  >
                    <Check className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="p-2 text-red-600 hover:text-red-700
                             dark:text-red-500 dark:hover:text-red-400
                             transition-colors duration-300"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={todo.completed}
                    onChange={() => toggleTodo(todo.id)}
                    className="task-checkbox"
                  />
                  <span className={`flex-1 text-gray-800 dark:text-gray-200 
                                  transition-colors duration-300
                                  ${todo.completed ? 'line-through text-gray-500 dark:text-gray-400' : ''}`}>
                    {todo.text}
                  </span>
                  <div className="flex gap-2">
                    <button
                      onClick={() => startEditing(todo)}
                      className="p-2 text-gray-600 hover:text-indigo-600 
                               dark:text-gray-400 dark:hover:text-indigo-400 
                               transition-colors duration-300"
                    >
                      <Edit2 className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => deleteTodo(todo.id)}
                      className="p-2 text-gray-600 hover:text-red-600
                               dark:text-gray-400 dark:hover:text-red-400
                               transition-colors duration-300"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
          {todos.length === 0 && (
            <div className="empty-state">
              <p className="text-gray-500 dark:text-gray-400">
                Your task list is empty. Add your first task above!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;